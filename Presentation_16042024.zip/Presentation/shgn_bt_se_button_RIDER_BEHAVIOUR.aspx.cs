using System;

namespace SHAB.Presentation {
	public partial class shgn_bt_se_button_RIDER_BEHAVIOUR : SHMA.CodeVision.Presentation.ButtonbarBase{
 
	}
}

