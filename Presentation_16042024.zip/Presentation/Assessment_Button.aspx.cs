using System;

namespace SHAB.Presentation {
	public partial class Assessment_Button : SHMA.CodeVision.Presentation.ButtonbarBase{
 
	}
}

