using System;
using System.Web;
using System.Web.UI;

namespace SHAB.Presentation
{
	public partial class shgn_ta_op_TAB_COUNTRYSETUP  : SHMA.CodeVision.Presentation.TabBase
	{
	}
}



