using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SHAB.Presentation
{
	/// <summary>
	/// Summary description for shgn_gp_gp_ILUS_ET_LF_LNFUFUNDS.
	/// </summary>
	public partial class shgn_gp_gp_ILUS_ET_LF_LNFUFUNDS  : SHMA.CodeVision.Presentation.GroupBase
	{

	}
}

