using System;

namespace SHAB.Presentation {
	public partial class MedicalDetail_Button : SHMA.CodeVision.Presentation.ButtonbarBase{
 
	}
}

